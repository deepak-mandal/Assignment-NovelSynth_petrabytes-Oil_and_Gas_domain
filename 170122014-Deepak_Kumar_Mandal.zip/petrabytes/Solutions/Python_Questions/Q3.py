#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 16:58:24 2021

@author: deepak
"""
n=123
print("data type of n is ", type(chr(0)))
print(chr(99))
print("data type of n is ", type(str(99)))
print(str(99))
print("data type of n is ", type(n))