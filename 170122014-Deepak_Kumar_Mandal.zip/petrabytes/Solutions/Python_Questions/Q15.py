list1= [12, 45, 2, 41, 31, 10, 8, 6, 4]

#Let the list to be sorted in assending order
list1.sort()
print("Largest element is ", list1[len(list1)-1])
print("Smallest element is: ", list1[0])
print("Second Largest element is: ", list1[len(list1)-2])
print("Second smallest element is ", list1[1])
