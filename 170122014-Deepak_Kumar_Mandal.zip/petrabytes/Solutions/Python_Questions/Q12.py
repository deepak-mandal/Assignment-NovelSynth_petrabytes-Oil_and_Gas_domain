#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 19:18:02 2021

@author: deepak
"""
#creating an array of 5 integers
arr=[1, 7, 96, 2, 67]

#displaying the array items
for i in arr:
	print(i)

#Accessing individual element through indexes
print(arr[0])
print(arr[1])
print(arr[4])

