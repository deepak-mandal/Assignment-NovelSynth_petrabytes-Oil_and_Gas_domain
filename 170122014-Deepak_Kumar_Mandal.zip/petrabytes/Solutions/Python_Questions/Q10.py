#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 18:39:43 2021

@author: deepak
"""
import random

#generate a random float number between 0.0 to 1.0
print(random.random())  

#returns a randomly selected element from the range
print(random.randrange(1, 10, 2))

#returns a random integer between two specified integer
print(random.randint(1, 100))